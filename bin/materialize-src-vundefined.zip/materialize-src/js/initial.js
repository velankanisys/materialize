// Check for jQuery.
if (typeof(jQuery) === 'undefined') {
  var jQuery = $ = require('jQuery');
}